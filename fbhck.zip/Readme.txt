please use pdf in description of our channel to understand tutorial properly
and thanks for subscribing keeps supporting

❤️🎀❤️🎀

noob hackers

search us on youtueb as

noob hackers